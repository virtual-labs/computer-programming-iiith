/*    */ package function;
/*    */ 
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JTextPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class function$1
/*    */   implements Runnable
/*    */ {
/*    */   function$1(function paramfunction) {}
/*    */   
/*    */   public void run()
/*    */   {
/* 46 */     this.this$0.square = new ImageIcon(getClass().getResource("/function/resources/square.jpg"));
/* 47 */     this.this$0.triangle = new ImageIcon(getClass().getResource("/function/resources/triangle.jpg"));
/* 48 */     this.this$0.rectangle = new ImageIcon(getClass().getResource("/function/resources/rectangle.jpg"));
/* 49 */     this.this$0.circle = new ImageIcon(getClass().getResource("/function/resources/circle.jpg"));
/* 50 */     this.this$0.finalfig = new ImageIcon(getClass().getResource("/function/resources/figure.jpg"));
/* 51 */     function.access$000(this.this$0);
/*    */     
/*    */ 
/* 54 */     function.access$100(this.this$0).setText("In this lab, we shall learn the use of functions in programming to break the problem into smaller independent steps. We will also learn how to define and call functions using the problem of finding the area of a geometrical figure as a sum of its components. So we create seperate functions for each different type of component, viz. square, rectangle, triangle and circle.\n\nStep1: Define the function to calculate the area of square: area_sq");
/*    */   }
/*    */ }


/* Location:              /media/ajeet/ae48a349-76aa-44ab-b02b-ac75e34a2282/virtual-labs/labs/cse02/exp5/lab/classes/!/function/function/function$1.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */